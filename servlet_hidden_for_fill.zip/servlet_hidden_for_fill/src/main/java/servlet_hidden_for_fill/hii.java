package servlet_hidden_for_fill;

public class hii {
	public static void main(String[] args) {
		System.out.println(System.getProperty("java.home"));
	}

}
